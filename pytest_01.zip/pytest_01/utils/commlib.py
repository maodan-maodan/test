import yaml

# 读取测试数据的函数get_test_data，通过这个函数从测试数据文件yaml中读取到了测试用例名称case，请求对象http和预期结果expected。这三部分分别是一个列表，通过zip将他们压缩到一起。
def get_test_data(test_data_path):
    case = []  # 存储测试用例名称
    http = []  # 存储请求对象
    expected = []  # 存储预期结果
    with open(test_data_path) as f:
        dat = yaml.load(f.read(), Loader=yaml.SafeLoader)
        test = dat['tests']
        for td in test:
            case.append(td.get('case', ''))
            http.append(td.get('http', {}))
            expected.append(td.get('expected', {}))
    parameters = zip(case, http, expected)
    return case, parameters