import requests
import json
import openpyxl

wb = openpyxl.load_workbook("D:\\workfile\\D_2109.xlsx")
sheet = wb['Sheet1']



def getResponse(url):
    results = requests.get(url)
    de_results = results.content.decode('GBK')
    return de_results

def sendRequest_getData(url):

    res = getResponse(url).encode('utf8').decode('unicode_escape')
    result = json.loads(res)
    if result is None:
        return
    else:
        for k, v in result.items():
            if k == "reply":
                value_items = v
                for key1, value1 in value_items.items():
                    if key1 == "Multiline":
                        value_items1 = value1
                        for key2, value2 in value_items1.items():
                            if key2 == "value":
                                value_items2 = value2
                                if value_items2 ==[]:
                                    continue
                                else:
                                    for key3, value3 in value_items2.items():
                                        if "D_2109" in value3:

                                            print(value3["D_2109"])
                                            sheet['A'] = value3["D_2109"]

ddddate= ["20210517","20210518","20210519","20210520","20210521","20210524","20210525","20210526"]
for i in range(1,592):
    for d in ddddate:
        url = "http://172.20.205.58:7070/php/getData.php?reqType=getData&qsid="+str(i)+"&reqName=10&cxrq="+d
        # print(str(i)+"     ")
        sendRequest_getData(url)
    print(i)

wb.save("D:\\workfile\\D_2109.xlsx")


