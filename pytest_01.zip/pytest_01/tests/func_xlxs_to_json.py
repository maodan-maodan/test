# xls
# import xlrd
# wb = xlrd.open_workbook('D:\\workfile\\study\\python\\pytest_01\\data\\test_data.xls')
# sheets=wb.sheet_names()
# print(sheets)

# xlsx
import openpyxl,json

def xlxs_to_json(url1,url2,sheetname,row,col):
    # url1 excel文件地址（xlsx格式）
    # url2 json文件地址（.json格式）
    # sheetname excel需要读取的表名称
    # row 表格需要被读取的行数
    # col 表格需要被读取的列数

    wb =openpyxl.load_workbook(url1)
    sheet = wb[sheetname]
    casedata ='{"case":['
    for j  in range (2,row+1):
        casedata = casedata + '{'
        if j<row:
            for i in range(1, col+1):
                sheetid = sheet.cell(row=1, column=i).value
                casedata = casedata+'"'+sheetid+'"'
                sheetValue = sheet.cell(row=j, column=i).value
                if i <col:
                    casedata = casedata+':"'+str(sheetValue)+'",'
                else:
                    casedata = casedata + ':"' + str(sheetValue) + '"'
            casedata = casedata+'},'
        else:
            for i in range(1, col+1):
                sheetid = sheet.cell(row=1, column=i).value
                casedata = casedata+'"'+sheetid+'"'
                sheetValue = sheet.cell(row=j, column=i).value
                if i <col:
                    casedata = casedata+':"'+str(sheetValue)+'",'
                else:
                    casedata = casedata + ':"' + str(sheetValue) + '"'
            casedata = casedata+'}'
    casedata = casedata+']}'
    jsondata= json.loads(casedata)
    with open(url2,'a',encoding='GBK')as fp:
        json.dump(jsondata,fp)

