# 响应为xml格式，get
from xml.etree import ElementTree
import requests
import xml.etree.ElementTree as ET


def getResponse(url):
    results = requests.get(url)
    de_results = results.content.decode('GBK')
    return de_results

def sendRequest_getData(url):
    res = getResponse(url)
    data = ElementTree.XML(res)
    tree = ET.ElementTree(data)
    root = tree.getroot()
    return root
#     data.find('code').text

def sendRequest_getData_Element(url,code):
    root = sendRequest_getData(url)
    # for node in list(root):
    #     print(node.text,node.tag)
    for node in root.findall(code):
        return node.text

