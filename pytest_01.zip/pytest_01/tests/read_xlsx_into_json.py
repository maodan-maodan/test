# xls
# import xlrd
# wb = xlrd.open_workbook('D:\\workfile\\study\\python\\pytest_01\\data\\test_data.xls')
# sheets=wb.sheet_names()
# print(sheets)

# xlsx


import openpyxl,json
wb =openpyxl.load_workbook('D:\\workfile\\study\\python\\pytest_01\\data\\test_data.xlsx')
sheet = wb['test_adddata']
# 组合json的单个括号
casedata ='{"case":['
for j  in range (2,5):
    casedata = casedata + '{'
    if j<4:
        for i in range(1, 9):

            sheetid = sheet.cell(row=1, column=i).value
            casedata = casedata+'"'+sheetid+'"'
            sheetValue = sheet.cell(row=j, column=i).value
            if i <8:
                casedata = casedata+':"'+str(sheetValue)+'",'
            else:
                casedata = casedata + ':"' + str(sheetValue) + '"'
        casedata = casedata+'},'
    else:
        for i in range(1, 9):
            sheetid = sheet.cell(row=1, column=i).value
            casedata = casedata+'"'+sheetid+'"'
            sheetValue = sheet.cell(row=j, column=i).value
            if i <8:
                casedata = casedata+':"'+str(sheetValue)+'",'
            else:
                casedata = casedata + ':"' + str(sheetValue) + '"'
        casedata = casedata+'}'
casedata = casedata+']}'
jsondata= json.loads(casedata)
with open('D:\\workfile\\study\\python\\pytest_01\\data\\test_newdata.json','a',encoding='GBK')as fp:
    json.dump(jsondata,fp)

    # for j in range(2,9):
    #
    #     print(sheetValue,end='   ')
    # print("")
    #       casedata ="{'"+sheetValue+"':'"


