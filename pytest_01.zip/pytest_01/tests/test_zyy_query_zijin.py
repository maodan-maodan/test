from func.functions import sendRequest_getData_Element

class test_zyy_query_zijin(object):
    def test_zyy_query_zijin():
        url = "http://172.20.0.236:8088/cgiwt?yyb_ip=218.75.74.105&yyb_port=8001&yyb_id=&yyb_backsrv=&lg_account=32019029&lg_account_type=%20&lg_commpwd=888888&sslsvr=0&dynpwd=&qsid=12&mobileuserid=200118639&progid=3051&session_id=134223811&client_ip=127.0.0.1&lg_tradepwd=300033&extend=client*mobile|mobile*client|mobileuser*mx_200118639|imei*|c_support*000000010001|ptgp_sptggt*1|imsi*|clientver*I037.08.282.10.00.92|hardwarecode*mobile:MAC%3A%2CIMSI%3A%2CIMEI%3A%2CUUID%3A61CA2085254246CE9D6624894C8504C5||||zjzh*32019029||&cmd=cmd_zijin_query"
        s = sendRequest_getData_Element(url,'kyje')
        print(s)
        assert s == '0.000'




