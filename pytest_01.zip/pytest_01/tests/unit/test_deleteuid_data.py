# 我们先写自动化测试用例，设置3个校验点：
# 验证请求中的reqtype与响应中的一致。
# 验证请求中的userid与响应中的一致。
# 验证响应中的xx"。


import requests
import bs4,base64
import json

#获取json格式文件内容


def test_incompany():
    f = json.load(open('D:\\workfile\\study\\python\\pytest_01\\data\\test_delete.json', 'r', encoding='GBK'))
    url = f.get("url")
    s = f.get("case")[0].get("s")
    uname = base64.b64encode(s.encode('GBK'))
    params = {
        "reqtype": f.get("case")[0].get("reqtype"),
        "userid": f.get("case")[0].get("userid"),
        "yybrid": f.get("case")[0].get("yybrid"),
        "khzh": uname,
        "cryptv": f.get("cryptv"),
        "zhlx": f.get("zhlx"),
        "app": f.get("app"),
        "version": f.get("case")[0].get("version"),
        "sessionid": f.get("case")[0].get("sessionid"),
        "expires": f.get("case")[0].get("expires"),
        "third_sign": f.get("case")[0].get("third_sign")
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36"
    }
    res = requests.get(url,params=params,headers=headers)
    results = res.content.decode("GBK")
    resultsx = bs4.BeautifulSoup(results, "lxml")
    r = resultsx.select('ret')[0]
    result1 = r.get("msg").strip()
    result2 = r.get("code").strip()

    assert result1 == "删除成功"
    assert result2 =="0"





