from urllib.parse import urlencode

import requests
import json
import bs4
from requests.exceptions import HTTPError


def test_modify():
    url = "http://whois.pconline.com.cn/"
    params = {
        "ip": "61.235.83.263"
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Mobile Safari/537.36"
    }
    params2 = json.dumps(params)
    param = {'p': params2}
    res = requests.get(url + "?" + urlencode(param))
    res.encoding = "gbk"
    results = bs4.BeautifulSoup(res.text,"lxml")
    r= results.select('p')
    result=r[1].getText().strip()
    print(result)
    assert result=="位置：浙江省杭州市 联通"
# 在Python 中，读写文件有3 个步骤：
# 1．调用open()函数，返回一个File 对象。
# 2．调用File 对象的read()或write()方法。
# 3．调用File 对象的close()方法，关闭该文件。

test_modify()