# 我们先写自动化测试用例，设置3个校验点：
# 验证请求中的reqtype与响应中的一致。
# 验证请求中的userid与响应中的一致。
# 验证响应中的xx"。


import requests
import bs4,base64
import json,pytest

#获取json格式文件内容
f = json.load(open('D:\\workfile\\study\\python\\pytest_01\\data\\test_delete.json', 'r', encoding='GBK'))

for k,v in f.items():
    if k == "case":
        data=v
        print(data)

@pytest.mark.parametrize('data',data)
def test_incompany(data):
    url = f.get("url")
    s =data.get("s")
    uname = base64.b64encode(s.encode('GBK'))
    params = {
        "reqtype":data.get("reqtype"),
        "userid": data.get("userid"),
        "yybrid": data.get("yybrid"),
        "khzh": uname,
        "cryptv": f.get("cryptv"),
        "zhlx": f.get("zhlx"),
        "app": f.get("app"),
        "version": data.get("version"),
        "sessionid": data.get("sessionid"),
        "expires": data.get("expires"),
        "third_sign": data.get("third_sign")
    }
    headers = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36"
    }
    res = requests.get(url,params=params,headers=headers)
    results = res.content.decode("GBK")
    resultsx = bs4.BeautifulSoup(results, "lxml")
    r = resultsx.select('ret')[0]
    result1 = r.get("msg").strip()
    result2 = r.get("code").strip()
    print(result1)
    if result1 =="删除成功" or result1 =="修改成功":
        assert result1
    else:
        assert result1 == 0
    assert result2 =="0"





