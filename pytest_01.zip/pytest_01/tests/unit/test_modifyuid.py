# 我们先写自动化测试用例，设置3个校验点：
# 验证请求中的reqtype与响应中的一致。
# 验证请求中的userid与响应中的一致。
# 验证响应中的xx"。


import requests
import bs4,base64

def test_incompany():
        url = "http://wt.10jqka.com.cn/wt"
        s = "maodan600022"
        uname = base64.b64encode(s.encode('GBK'))
        params = {
            "reqtype": "wt_modify_userinfo",
            "userid": "472342928",
            "yybrid": "2",
            "khzh": uname,
            "cryptv": "1",
            "zhlx": "dbkidfGO",
            "app": "pc",
            "version": "E065.19.06.160",
            "sessionid": "164b4a9e58f71b9a69b7a96dcb3dc0fda",
            "expires": "2020-10-29 09:55:38",
            "third_sign": "BDEBKNOLCIPGLBHGBGDCELBHBMDJNHFLNMODDNGCNIKNABHBJOBDPKCHMMKLDPJFKFBFELBPHLENONBEJACGPOEHDLOCPMMCNAJBILFIANHANDOFGLILBKHLCGNNDLHJOJOADLFNCEIPKEEPFGAFLFBLGJEGGNKBBKBPFNBLPPICIDAADOFPDELLNLDEGOEFDFCFAKAIFABGDOLLBFIPLOMGJGDDOFLLPNNCCAGLBJGNJFADABAJIPHEGLCDMKIG"
        }
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36"
        }
        res = requests.get(url,params=params,headers=headers)
        results = res.content.decode("GBK")
        resultsx = bs4.BeautifulSoup(results, "lxml")
        r = resultsx.select('ret')[0]
        result1 = r.get("msg").strip()
        result2 = r.get("code").strip()
        assert result1 == "修改成功"
        assert result2 =="0"





