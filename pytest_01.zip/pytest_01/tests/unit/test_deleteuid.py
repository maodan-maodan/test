# 我们先写自动化测试用例，设置3个校验点：
# 验证请求中的reqtype与响应中的一致。
# 验证请求中的userid与响应中的一致。
# 验证响应中的xx"。


import requests
import bs4,base64

def test_incompany():
        url = "http://wt.10jqka.com.cn/wt"
        s = "maodan300033"
        uname = base64.b64encode(s.encode('GBK'))
        params = {
            "reqtype": "wt_delete_userinfo",
            "userid": "467427084",
            "yybrid": "56",
            "khzh": uname,
            "cryptv": "1",
            "zhlx": "",
            "app": "pc",
            "version": "E065.19.06.160",
            "sessionid": "1e0aaa76ca430a5cf31ee2080bf4a1c44",
            "expires": "2020-10-28 15:37:49",
            "third_sign": "BFBMKJADGNHBMKPALCHMCHMGPOKNABCEOADMDCCCBIMAJDOFABJPLPLOAKNNJBIIPMPMCFDBCOGCKMEDLHPGJBFMHGJJAFFEPLECHHEKHILHLFCDFKAOEKAHFFDPBBJHDAOMAOENIPPLIPPFPBKHPFLEMIHBGHFIDOJOCFMMKKBNJAALGEADFHOPGNHHBFDHDEIOKCANKHGKMJADKNPJKCBGDOOLILLNIAJDNEEJBHGDEGLFAFNOBMAGDNHKEHBK"
        }
        headers = {
            "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Mobile Safari/537.36"
        }
        res = requests.get(url,params=params,headers=headers)
        results = res.content.decode("GBK")
        resultsx = bs4.BeautifulSoup(results, "lxml")
        r = resultsx.select('ret')[0]
        result1 = r.get("msg").strip()
        result2 = r.get("code").strip()
        assert result1 == "删除成功"
        assert result2 =="0"
        





