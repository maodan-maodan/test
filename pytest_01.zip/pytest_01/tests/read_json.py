import json

#获取json格式文件内容
filename =json.load(open('D:\\workfile\\study\\python\\pytest_01\\data\\test_delete.json','r',encoding='GBK'))
# str = json.dumps(filename,indent=4)
# str1 = json.loads(str)
str2=filename.get("case")[0].get("s")
print(str2)

# json.dumps()  str格式    dumps：将字典转换为字符串
# json.loads()  json格式   loads: 将字符串转换为字典
# json.dump()   dump: 将数据写入json文件中
# json.load()   load: 把文件打开，并把字符串变换为数据类型