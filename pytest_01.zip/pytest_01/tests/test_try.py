# xls
# import xlrd
# wb = xlrd.open_workbook('D:\\workfile\\study\\python\\pytest_01\\data\\test_data.xls')
# sheets=wb.sheet_names()
# print(sheets)

# xlsx


import openpyxl
wb =openpyxl.load_workbook('D:\\workfile\\study\\python\\pytest_01\\data\\test_data.xlsx')
sheet = wb.sheetnames[0]

