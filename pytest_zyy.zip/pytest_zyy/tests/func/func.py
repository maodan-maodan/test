import pymysql.connections as db_connection

class Conn:
    """数据库相关"""
    def __init__(self,sql):
        """初始化数据库连接信息"""
        self.sql = sql
        self.host = "localhost"
        self.user = "maomao"
        self.passwd = "root123"
        self.db = "python1"

    #连接数据库，创建游标
    def db_conn(self):
        self.db_con = db_connection.Connection(host=self.host, user=self.user, passwd=self.passwd, db=self.db)
        cursor = self.db_con.cursor()
        cursor.execute(self.sql)
        return cursor

    #关闭数据库游标
    def db_close(self):
        self.db_conn().close()

    #查询数据库，查询语句sql 查询返回sql对应条数
    def db_query_count(self):
        count_num = self.db_conn().execute(self.sql)
        return count_num

    # 查询数据库，查询语句sql 查询返回sql第一行（列表格式）
    def db_query_detail(self):
        fetch_data = self.db_conn().fetchone()
        return fetch_data

    # 查询数据库，查询语句sql 查询返回sql所有行（列表格式）
    def db_query_details(self):
        fetch_data = self.db_conn().fetchall()
        return fetch_data

