import xml.etree.ElementTree as ET
import requests
import __init
import func


def test_login_request():
    qsid = 12
    start_line = 0
    count_line = 1
    start_linex = 0
    count_linex = 1
    sql = "SELECT * FROM qs_items WHERE qsid = %s limit %s,%s" % (qsid, start_line, count_line)
    #    print(sql)
    sqlx = "SELECT * FROM users WHERE qsid = %s and valid_tag = 1 limit %s,%s" % (qsid, start_linex, count_linex)
    #    print(sqlx)
    _db = func.Conn(sql)
    _dbx = func.Conn(sqlx)

    #返回数据库查回的数据
    fetch_data = _db.db_query_detail()
    fetch_datax = _dbx.db_query_detail()

    _db.db_close()
    _dbx.db_close()

    url = "http://172.20.0.236:8088/cgiwt "
    #组合url请求
    data = {
        "yyb_ip":fetch_data[2],
        "yyb_port":fetch_data[3],
        "yyb_id": "",
        "yyb_backsrv": "",
        "lg_account":fetch_datax[1],
        "lg_account_type":"%20",
        "lg_commpwd":"888888",
        "sslsrv":"0",
        "dynpwd":"",
        "qsid":qsid,
        "mobileuserid":"200118639",
        "progid":"3051",
        "sessionid":"134223811",
        "lg_tradepwd":fetch_datax[2],
        "extend":"client*mobile|mobile*client|mobileuser*18806513195|imei*|c_support*000000010001|ptgp_sptggt*1|imsi*|clientver*I073.08.282.10.00.92|hardwarecode*mobile:MAC%3A%2CIMSI%3A%2CIMSI%3A61CA2085254246CE9D6624894C8504C5||||zjzh*"+fetch_datax[1]+"||",
        "cmd":"cmd_qu_account"
    }
    send_request = requests.request("GET",url=url,params = data).content.decode("GBK")
    response = ET.fromstring(send_request)
    ret_code = response.find('ret_msg').text

    assert ret_code.strip() == '请求成功'
