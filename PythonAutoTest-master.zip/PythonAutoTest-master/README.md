# PythonAutoTest
Python+unittest框架api自动化测试脚本

对应专栏文章4.3-4.5

专栏【接口测试之代码实例21讲】地址：https://www.nowcoder.com/tutorial/10032/index
