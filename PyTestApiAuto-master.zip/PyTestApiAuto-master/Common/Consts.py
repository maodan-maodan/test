# coding=utf-8
__author__ = 'wujiayi'
__time__ = '2019/10/9 14:23'

"""
接口全局变量
"""

# 接口全局配置
API_ENVIRONMENT_DEBUG = 'debug'
API_ENVIRONMENT_RELEASE = 'release'

# 接口响应时间list，单位毫秒
STRESS_LIST = []

# 接口执行结果list
RESULT_LIST = []

# 测试环境调试参数
DEBUG = '1'

# 用户参数
ADMIN_NAME = 'admin'
ADMIN_ID = '727'

EXECUTOR_CW_NAME = 'executor_cw'
EXECUTOR_CW_ID = '1098'
