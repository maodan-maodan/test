#coding=utf-8

"""
封装log方法
"""

import logging
import os
import time


LEVELS = {
    "debug":logging.DEBUG,
    "info":logging.INFO,
    "warning":logging.WARNING,
    "error":logging.ERROR,
    "cirtical":logging.CRITICAL
}

logger = logging.getLogger()
level = 'default'

def create_file(filename):
    path = filename[0:filename.rfind('/')]
    if not os.path.isdir(path):
        os.makedirs(path)
    if not os.path.isfile(filename):
        fd = open(filename,mode='w',encoding='utf-8')
        fd.close()
    else:
        pass


def set_handler(levels):
    if levels == 'error':
        logger.removeHandler(Mylog.err_handler)
    logger.removeHandler(Mylog.handler)

    logger.removeHandler(Mylog.console)

def remove_handler(levels):
    if levels == 'error':
        logger.removeHandler(Mylog.err_handler)
    logger.removeHandler(Mylog.handler)
    logger.removeHandler(Mylog.console)

def get_current_time():
    return time.strftime(Mylog.date,time.localtime(time,time()))

class Mylog(object):
    path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    log_file = path+




